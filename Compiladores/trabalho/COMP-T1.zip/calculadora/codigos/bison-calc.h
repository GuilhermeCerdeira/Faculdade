#ifndef BISON_CALC_H
#define BISON_CALC_H

extern int yylineno;
void yyerror(char *s, ...);

/* Tabela de símbolos */
struct symbol {
    /* Nome de uma variável */
    char *name;
    double value;
    struct ast *func;        /* Declaração para função */
    struct symlist *syms;    /* Lista de argumentos */
};

/* Tabela de símbolos de tamanho fixo */
#define NHASH 9997
extern struct symbol symtab[NHASH];
struct symbol *lookup(char *);

/* Lista de símbolos, para argumentos */
struct symlist {
    struct symbol *sym;
    struct symlist *next;
};

struct symlist *newsymlist(struct symbol *sym, struct symlist *next);
void symlistfree(struct symlist *sl);

/* Tipos de nós */
/*
 * 0-7: Operadores de comparação, 04 igual, 02 menor que, 01 maior que
 * L: Expressão ou lista de comandos
 * I: Comando IF
 * W: Comando WHILE
 * N: Referência a símbolo
 * =: Atribuição
 * S: Lista de símbolos
 * F: Chamada de função pré-definida
 * C: Chamada de função definida pelo usuário
 */

enum bifs {
    /* Funções pré-definidas */
    B_sqrt = 1,
    B_exp,
    B_log,
    B_print
};

/* Nós na AST */
/* Todos têm o campo "nodetype" inicial em comum */
struct ast {
    int nodetype;
    struct ast *l;
    struct ast *r;
};

struct fncall {
    int nodetype;       /* Tipo 'B' (built-in) */
    struct ast *l;      /* Argumentos */
    enum bifs functype; /* Tipo da função */
};


struct ufncall {
    /* Funções do usuário */
    int nodetype;            /* Tipo C */
    struct ast *l;           /* Lista de argumentos */
    struct symbol *s;
};

struct flow {
    int nodetype;       /* Tipo: 'I', 'W', ou 'F' */
    struct ast *init;   /* Inicialização (NULL para IF/WHILE) */
    struct ast *cond;   /* Condição */
    struct ast *el;     /* Incremento ou else (NULL para IF/WHILE) */
    struct ast *tl;     /* Corpo */
};


struct numval {
    int nodetype;            /* Tipo K */
    double number;
};

struct symref {
    int nodetype;            /* Tipo N */
    struct symbol *s;
};

struct symasgn {
    int nodetype;            /* Tipo = */
    struct symbol *s;
    struct ast *v;           /* Valor a ser atribuído */
};

/* Construção de uma AST */
struct ast *newast(int nodetype, struct ast *l, struct ast *r);
struct ast *newcmp(int cmptype, struct ast *l, struct ast *r);
struct ast *newfunc(int functype, struct ast *l);
struct ast *newcall(struct symbol *s, struct ast *l);
struct ast *newref(struct symbol *s);
struct ast *newasgn(struct symbol *s, struct ast *v);
struct ast *newnum(double d);
struct ast *newflow(int nodetype, struct ast *init, struct ast *cond, struct ast *inc, struct ast *body);

/* Definição de uma função */
void dodef(struct symbol *name, struct symlist *syms, struct ast *stmts);

/* Avaliação de uma AST */
double eval(struct ast *);

/* Deletar e liberar uma AST */
void treefree(struct ast *);

#endif

